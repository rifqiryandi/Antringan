<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if(!isset($_SESSION['data'])){
			$message = "Maaf, anda harus login terlebih dahulu!";
			$this->session->sess_destroy();
	   	    echo "<script type='text/javascript'>
	   			alert('$message');
	   			window.location.href = '". base_url() ."C_Login';</script>";
    }
    }
}


/* End of file filename.php */

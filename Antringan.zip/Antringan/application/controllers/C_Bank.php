<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Bank extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Bank');
		}
	

		function viewDataBank()
		{
			$data['data'] = $this->M_Bank->viewBank();
			$this->load->view('V_Bank/Data_Bank', $data);
		}

		function deleteBank()
		{
			$id = $this->input->post('id');
		 	$this->M_Bank->delete($id);
		 	redirect('C_Bank/viewDataBank','refresh');
		}

		function viewEditBank()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Bank->viewBankById($id);
			$this->load->view('V_Bank/Edit_Bank', $data);
		}

		function viewDetailBank()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Bank->viewBankById($id);
			$this->load->view('V_Bank/Detail_Bank', $data);
		}

		function proEditBank()
		{
			$form = $this->input->post();
			$data = array(
				'Nama_Pemilik' => $form['nama'],
				'No_Rekening' => $form['norek'],
				'Tata_Cara' => $form['tata_cara'],
				'Status' => $form['Status']
			);
			$this->M_Bank->update($form['Id'],$data);
			redirect('C_Bank/viewDataBank','refresh');
		}

		function tambahDataBank()
		{
			$this->load->view('V_Bank/Tambah_Bank');
		}

		function proTambahBank()
		{
			$form = $this->input->post();
			$data = array(
				'Nama_Pemilik' => $form['nama'],
				'No_Rekening' => $form['norek'],
				'Tata_Cara' => $form['tata_cara'],
				'Status' => $form['Status']
			);
			$this->M_Bank->insert($data);
			redirect('C_Bank/viewDataBank','refresh');
		}

	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>
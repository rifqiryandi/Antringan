<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Saldo extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
            $this->load->model('M_Saldo');
            $this->load->model('M_Konsumen');
		}
	

		function viewDataSaldo()
		{
            $data['data'] = $this->M_Saldo->viewSaldo();
            $data['data_k'] = $this->M_Konsumen->viewKonsumen();
			$this->load->view('V_Saldo/Data_Saldo', $data);
		}

		function deleteSaldo()
		{
			$id = $this->input->post('id');
		 	$this->M_Saldo->delete($id);
		 	redirect('C_Saldo/viewDataSaldo','refresh');
		}


		function viewDetailSaldo()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Saldo->viewSaldoById($id);
			$this->load->view('V_Saldo/Detail_Saldo', $data);
		}

		function proEditSaldo()
		{
			$form = $this->input->post();
			$data_k = $this->M_Konsumen->viewKonsumenById($form['Id_Konsumen']);
            if ($form['kategori']=="Tambah") {
                $hasil = $data_k[0]->saldo + $form['saldo'];
				$data = array(
                    'status_permintaan' => 1
                );
                $data2 = array(
                    'saldo' => $hasil
				);
				$this->M_Saldo->update($form['Id_Konsumen'],$form['Id'],$data,$data2); 
					
                redirect('C_Saldo/viewDataSaldo','refresh');
                
            }elseif ($form['kategori']=="Tarik") {

                if ($data_k[0]->saldo>=$form['saldo']) {
                    $hasil = $data_k[0]->saldo - $form['saldo'];
                    $data = array(
                        'status_permintaan' => 1
                    );
                    $data2 = array(
                        'saldo' => $hasil
                    );
                    $this->M_Saldo->update($form['Id_Konsumen'],$form['Id'],$data,$data2);
                    redirect('C_Saldo/viewDataSaldo','refresh');
                }else {
                    $message = "Maaf Saldo Tidak Mencukupi";
                    echo "<script type='text/javascript'>
	   			    alert('$message');
	   			    window.location.href = '". base_url() ."C_Saldo/viewDataSaldo';</script>";
                }
                
            }
			
        }
        
        public function Cancel()
        {
            
            $data = array(
                'status_permintaan' => 0
            );
            $this->M_Saldo->updatecancel($_GET['Id'],$data);
            redirect('C_Saldo/viewDataSaldo','refresh');
        }

	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>

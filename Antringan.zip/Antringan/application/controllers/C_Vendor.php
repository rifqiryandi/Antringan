<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Vendor extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Vendor');
		}
	

		function viewDataVendor()
		{
			$data['data'] = $this->M_Vendor->viewVendor();
			$this->load->view('V_Vendor/Data_Vendor', $data);
		}



		public function inputvendor()
	{
		$data = $this->M_Vendor->viewVendor();
        $this->session->set_userdata('all_data',$data);

		$this->load->view('V_Vendor/Input_Vendor',array('error' => ' ' ),$data);
	}

	public function prosesinputvendor(){
        $id_ven 		    = $this->input->post('Id');
        $username			= $this->input->post('Username');
		$pass 				= $this->input->post('Password');
		$psw 				= md5($pass);
		$nama				= $this->input->post('Nama');
		$status				= $this->input->post('Status');
		$waktu_tutup		= $this->input->post('Waktu_Tutup');
		$alamat				= $this->input->post('Alamat'); 
		$created_at			= date("Y-m-d h:i:sa");	
 
		$this->M_Vendor->inputVendor($id_ven,$username,$psw,$nama,$status,$waktu_tutup,$alamat,$created_at);
  		
        redirect('C_Vendor/viewDataVendor');

	}

	public function editvendor()
	{
		$query['data'] = $this->M_Vendor->getVendor($_GET['Id']);
		$this->load->view('V_Vendor/Edit_Vendor',$query);
	}

	public function detailvendor()
	{
		$query['data'] = $this->M_Vendor->getVendor($_GET['Id']);	

		$this->load->view('V_Vendor/Detail_Vendor',$query);
	}

	public function proseseditvendor(){
        $id_ven 		    = $this->input->post('Id');
        $username			= $this->input->post('Username');
		$pass 				= $this->input->post('Password');
		$psw 				= md5($pass);
		$nama				= $this->input->post('Nama');
		$status				= $this->input->post('Status');
		$waktu_tutup		= $this->input->post('Waktu_Tutup');
		$alamat				= $this->input->post('Alamat');
		$created_at			= date("Y-m-d h:i:sa");	


		$this->M_Vendor->editVendor($id_ven,$username,$psw,$nama,$status,$waktu_tutup,$alamat, $created_at);
        redirect('C_Vendor/viewDataVendor');

	}

	public function hapusvendor()
         {

            $id = $_GET['Id'];
            $this->M_Vendor->hapusVendor($id);
            redirect('C_Vendor/viewDataVendor');
            
    }

	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>

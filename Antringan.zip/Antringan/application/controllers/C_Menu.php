<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Menu extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Menu');
			$this->load->model('M_Vendor');

		}

		public function inputMenu()
		{
			$data['data_vendor'] = $this->M_Vendor->getVendor($_GET['Id_Vendor']);	
			$this->load->view('V_Menu/Input_Menu',$data);
		}
	

		function viewDataMenu()
		{
			$data['data_menu'] = $this->M_Menu->getMenuByVendor($_GET['Id']);
			$data['data_vendor'] = $this->M_Vendor->getVendor($_GET['Id']);	
			$this->load->view('V_Menu/Data_Menu', $data);
		}

		function detailMenu()
		{
			$data['data_menu'] = $this->M_Menu->getMenu($_GET['Id']);
			$data['data_vendor'] = $this->M_Vendor->getVendor($_GET['Id_Vendor']);	
			$this->load->view('V_Menu/Detail_Menu', $data);
		}

		function updateMenu()
		{
			$data['data_menu'] = $this->M_Menu->getMenu($_GET['Id']);
			$data['data_vendor'] = $this->M_Vendor->getVendor($_GET['Id_Vendor']);	
			$this->load->view('V_Menu/Edit_Menu', $data);
		}

		function changeStatus()
		{	
			$this->M_Menu->changeStatus($_GET['Id'],$_GET['Status']);	
			redirect("C_Menu/viewDataMenu?Id=".$_GET['Id_Vendor']);
		}

		public function prosesTambahMenu(){
			$nama				= $this->input->post('Nama');
			$harga				= $this->input->post('Harga');
			$deskripsi			= $this->input->post('Deskripsi');
			$id_vendor			= $this->input->post('Id_vendor');
			$created_at			= date("Y-m-d h:i:sa");	
	
	
			$this->M_Menu->tambahMenu($id_vendor,$nama,$harga,$deskripsi,$created_at);
			redirect("C_Menu/viewDataMenu?Id=".$id_vendor);
	
		}

		public function proseseditMenu(){
			$id 		    	= $this->input->post('Id');
			$nama				= $this->input->post('Nama');
			$harga			= $this->input->post('Harga');
			$deskripsi			= $this->input->post('Deskripsi');
			$id_vendor			= $this->input->post('Id_vendor');
			$updated_at			= date("Y-m-d h:i:sa");	
	
	
			$this->M_Menu->editMenu($id,$nama,$harga,$deskripsi,$updated_at);
			redirect("C_Menu/viewDataMenu?Id=".$id_vendor);
	
		}



	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>

<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Admin extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Admin');
		}
	
		// public function login()
		// {
		// 	$this->load->view('login');
		// }

		public function index()
		{
			$data['jmlVendor'] = $this->M_Admin->jmlVendor();
			$data['jmlKonsumen'] = $this->M_Admin->jmlKonsumen();
			$data['jmlTransaksi'] = $this->M_Admin->jmlTransaksi();
			$data['totOmset'] = $this->M_Admin->totOmset();
			$data['jmlMenu'] = $this->M_Admin->jmlMenu();
			$this->load->view('index2',$data);
		}

		function viewDataKonsumen()
		{
			$data['data'] = '';
			$this->load->view('V_Konsumen/Data_Konsumen', $data);
		}

		function viewDataVendor()
		{
			$data['data'] = '';
			$this->load->view('V_Vendor/Data_Vendor', $data);
		}

		function viewDataTransaksi()
		{
			$data['data'] = '';
			$this->load->view('V_Transaksi	/Data_Transaksi', $data);
		}
	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>
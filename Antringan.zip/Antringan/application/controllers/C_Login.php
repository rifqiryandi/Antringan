<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_Login extends CI_Controller{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_Login');
        
        //Do your magic here
    }

    public function index()
	{
		if (isset($_SESSION['data'])) {
			redirect(base_url('C_Admin'),'refresh');
		}
		$this->load->view('login');
    }
    
    public function LoginCek()
    {
        if (isset($_POST['signin'])) {
            $user 	= $this->input->post('username',true);
            $pass 	= $this->input->post('password',true);
            $psw   	= md5($pass);
            $cek    = $this->M_Login->proseslogin($user,$psw);

            $hasil = count($cek);
            if ($hasil > 0) {
                $data = array(
                    'Id'       => $cek[0]->Id,
                    'Username' => $cek[0]->Username,
                    'Password' => $cek[0]->Password,
                    'Role'     => $cek[0]->Role
                    
                );
                $_SESSION['data'] = $data;
                $this->session->set_userdata('Role', $data['Role']);
                $this->session->set_userdata('Username', $data['Username']);
				$this->session->set_userdata('password',$data['Password']);
                
                redirect(base_url('C_Admin'),'refresh');
            }else {
                $message = "Password / Username Salah";
                    echo "<script type='text/javascript'>
	   			    alert('$message');
	   			    window.location.href = '". base_url() ."C_Login';</script>";
                redirect(base_url('C_Login'),'refresh');
            }
        }
    }

    public function logout(){

		$this->session->sess_destroy();
        // $this->session->unset_userdata('user_id');
        $message = "Berhasil Log Out !!";
                    echo "<script type='text/javascript'>
	   			    alert('$message');
	   			    window.location.href = '". base_url() ."C_Login';</script>";
		// redirect(base_url().'C_Login');

	}


    
}


/* End of file filename.php */

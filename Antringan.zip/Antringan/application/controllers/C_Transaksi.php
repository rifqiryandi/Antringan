<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Transaksi extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Transaksi');
		}
	

		function viewDataTransaksiLunas()
		{
			$data['data'] = $this->M_Transaksi->viewTransaksiLunas();
			$this->load->view('V_Transaksi/Data_Transaksi', $data);
		}

		function viewDataTransaksiBelumLunas()
		{
			$data['data'] = $this->M_Transaksi->viewTransaksiBelumLunas();
			$this->load->view('V_Transaksi/Data_Transaksi', $data);
		}

		public function DetailTransaksiById()
		{
			$data['dt'] = $this->M_Transaksi->DetailTransaksiById($_GET['Status'], $_GET['Id']);
			// if ($_GET['Status']=="Lunas") {
			// 	$data['num'] =  1;
			// }elseif ($_GET['Status']=="Belum_Lunas") {
			// 	$data['num'] = 0;
			// }
			$data['num'] = $_GET['Status'];
			$this->load->view('V_Transaksi/Detail_Transaksi', $data);
		}
	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>

<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Konsumen extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Konsumen');
		}
	

		function viewDataKonsumen()
		{
			$data['data'] = $this->M_Konsumen->viewKonsumen();
			$this->load->view('V_Konsumen/Data_Konsumen', $data);
		}

		function deleteKonsumen()
		{
			$id = $this->input->post('id');
		 	$this->M_Konsumen->delete($id);
		 	redirect('C_Konsumen/viewDataKonsumen','refresh');
		}

		function viewEditKonsumen()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Konsumen->viewKonsumenById($id);
			$this->load->view('V_Konsumen/Edit_Konsumen', $data);
		}

		function viewDetailKonsumen()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Konsumen->viewKonsumenById($id);
			$this->load->view('V_Konsumen/Detail_Konsumen', $data);
		}

		function proEditKonsumen()
		{
			$form = $this->input->post();
			$data = array(
				'nama' => $form['nama'],
				'email' => $form['email'],
				'saldo' => $form['saldo'],
				'point' => $form['poin']
			);
			$this->M_Konsumen->update($form['Id'],$data);
			redirect('C_Konsumen/viewDataKonsumen','refresh');
		}

		function tambahDataKonsumen()
		{
			$this->load->view('V_Konsumen/Tambah_Konsumen');
		}

		function proTambahKonsumen()
		{
			$form = $this->input->post();
			$data = array(
				'nama' => $form['nama'],
				'email' => $form['email'],
				'saldo' => $form['saldo'],
				'point' => $form['poin']
			);
			$this->M_Konsumen->insert($data);
			redirect('C_Konsumen/viewDataKonsumen','refresh');
		}

	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>

<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class C_Kategori extends MY_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('M_Kategori');
		}
	

		function viewDataKategori()
		{
			$data['data'] = $this->M_Kategori->viewKategori();
			$this->load->view('V_Kategori/Data_Kategori', $data);
		}

		function deleteKategori()
		{
			$id = $this->input->post('id');
		 	$this->M_Kategori->delete($id);
		 	redirect('C_Kategori/viewDataKategori','refresh');
		}

		function viewEditKategori()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Kategori->viewKategoriById($id);
			$this->load->view('V_Kategori/Edit_Kategori', $data);
		}

		function viewDetailKategori()
		{
			$id = $this->input->post('id');
			$data['dt'] = $this->M_Kategori->viewKategoriById($id);
			$this->load->view('V_Kategori/Detail_Kategori', $data);
		}

		function proEditKategori()
		{
			$form = $this->input->post();
			$data = array(
				'Nama_Pemilik' => $form['nama'],
				'No_Rekening' => $form['norek'],
				'Tata_Cara' => $form['tata_cara'],
				'Status' => $form['Status']
			);
			$this->M_Kategori->update($form['Id'],$data);
			redirect('C_Kategori/viewDataKategori','refresh');
		}

		function tambahDataKategori()
		{
			$this->load->view('V_Kategori/Tambah_Kategori');
		}

		function proTambahKategori()
		{
			$form = $this->input->post();
			$data = array(
				'Nama_Pemilik' => $form['nama'],
				'No_Rekening' => $form['norek'],
				'Tata_Cara' => $form['tata_cara'],
				'Status' => $form['Status']
			);
			$this->M_Kategori->insert($data);
			redirect('C_Kategori/viewDataKategori','refresh');
		}

	
	}
	
	/* End of file C_Admin.php */
	/* Location: ./application/controllers/C_Admin.php */
?>

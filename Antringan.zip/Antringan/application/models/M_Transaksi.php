<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Transaksi extends CI_Model {
	
		function viewTransaksiLunas()
		{
			$this->db->select('a.Id, a.id_pesanan ,a.metode_pembayaran, b.total_Harga ,c.nama, c.email ,a.status AS "status_pembayaran", d.status AS "Status_Pesanan"');
			$this->db->from('t_transaksi a');
			$this->db->join('t_pesanan b', 'b.id = a.id_pesanan');
			$this->db->join('t_konsumen c', 'c.id = b.id_konsumen');
			$this->db->join('t_pesan_menu d', 'b.id = d.id_pesanan');
			
			$this->db->where('a.status', 1);
			
			return $this->db->get()->result();
		}

		function viewTransaksiBelumLunas()
		{
			$this->db->select('a.id, a.id_pesanan ,a.metode_pembayaran, b.total_Harga ,c.nama, c.email ,a.status AS "status_pembayaran", d.status AS "Status_Pesanan"');
			$this->db->from('t_transaksi a');
			$this->db->join('t_pesanan b', 'b.id = a.id_pesanan');
			$this->db->join('t_konsumen c', 'c.id = b.id_konsumen');
			$this->db->join('t_pesan_menu d', 'b.id = d.id_pesanan');

			
			$this->db->where('a.status', 0);
			
			return $this->db->get()->result();
		}

		function DetailTransaksiById($status, $id)
		{
			$this->db->select('*');
			$this->db->from('t_transaksi a');
			$this->db->join('t_pesanan b', 'b.id = a.id_Pesanan');
			$this->db->join('t_konsumen c', 'c.Id = b.id_Konsumen');
			$this->db->where('a.status', $status);
			$this->db->where('a.id_pesanan', $id);
			
			
			return $this->db->get()->result();
		}


	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

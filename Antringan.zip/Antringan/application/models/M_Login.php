<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Login extends CI_Model {
        function proseslogin($user, $pass){

           $this->db->from('tb_admin'); 
           $this->db->where('Username',$user);
           $this->db->where('Password',$pass);
 
           $query = $this->db->get();
          return $query->result();
      }
		
	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>
<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Bank extends CI_Model {

		function insert($data)
		{
			$this->db->insert('m_bank', $data);
		}
		
		function viewBank()
		{
			$this->db->select('*');
			$this->db->from('m_bank');
			return $this->db->get()->result();
		}

		function viewBankById($where)
		{
			$this->db->select('*');
			$this->db->from('m_Bank');
			$this->db->where('id', $where);
			return $this->db->get()->result();
		}

		function delete($where)
		{
			$this->db->where('id', $where);
			$this->db->delete('m_Bank');
		}

		function update($where,$data)
		{
			$this->db->where('Id', $where);
			$this->db->update('m_Bank', $data);
		}
		
	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

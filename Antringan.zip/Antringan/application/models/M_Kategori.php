<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Kategori extends CI_Model {

		function insert($data)
		{
			$this->db->insert('t_kategori', $data);
		}
		
		function viewKategori()
		{
			$this->db->select('*');
			$this->db->from('t_kategori');
			return $this->db->get()->result();
		}

		function viewKategoriById($where)
		{
			$this->db->select('*');
			$this->db->from('t_kategori');
			$this->db->where('id', $where);
			return $this->db->get()->result();
		}

		function delete($where)
		{
			$this->db->where('id', $where);
			$this->db->delete('t_kategori');
		}

		function update($where,$data)
		{
			$this->db->where('Id', $where);
			$this->db->update('t_kategori', $data);
		}
		
	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

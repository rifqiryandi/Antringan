<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Konsumen extends CI_Model {

		function insert($data)
		{
			$this->db->insert('t_konsumen', $data);
		}
		
		function viewKonsumen()
		{
			$this->db->select('*');
			$this->db->from('t_konsumen');
			return $this->db->get()->result();
		}

		function viewKonsumenById($where)
		{
			$this->db->select('*');
			$this->db->from('t_konsumen');
			$this->db->where('id', $where);
			return $this->db->get()->result();
		}

		function delete($where)
		{
			$this->db->where('id', $where);
			$this->db->delete('t_konsumen');
		}

		function update($where,$data)
		{
			$this->db->where('id', $where);
			$this->db->update('t_konsumen', $data);
		}
		
	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

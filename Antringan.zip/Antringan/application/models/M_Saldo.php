<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Saldo extends CI_Model {

		function insert($data)
		{
			$this->db->insert('t_permintaan_saldo', $data);
		}
		
		function viewSaldo()
		{
			$this->db->select('*');
			$this->db->from('t_permintaan_saldo');
			return $this->db->get()->result();
		}

		function viewSaldoById($where)
		{
			$this->db->select('*');
			$this->db->from('t_permintaan_saldo');
			$this->db->where('id', $where);
			return $this->db->get()->result();
		}


		function update($id_konsumen,$id,$data,$data2)
		{
			$this->db->where('id', $id);
            $this->db->update('t_permintaan_saldo', $data);
            
            $this->db->where('id', $id_konsumen);
			$this->db->update('t_konsumen', $data2);
        }

        function updatecancel($id,$data)
		{
			$this->db->where('Id', $id);
            $this->db->update('t_permintaan_saldo', $data);
            
        }
        

		
	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

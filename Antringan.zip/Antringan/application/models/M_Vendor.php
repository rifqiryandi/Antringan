<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Vendor extends CI_Model {
	
		function viewVendor()
		{
			$this->db->select('*');
			$this->db->from('t_vendor');
			return $this->db->get()->result();
		}

		public function getVendor($id){
			$this->db->select('*');
			  $this->db->from('t_vendor');
			$this->db->where('Id',$id);
	
			$query = $this->db->get();
			return $query->result();
		}

		public function inputVendor($id_ven,$username,$psw,$nama,$status,$waktu_tutup,$alamat,$created_at){

			$data = array(
				'Id' => $id_ven,
			   'Username' =>  $username,
			   'Password' =>  $psw,
			   'Nama'=>  $nama,
			   'Status' => $status,
			   'Waktu_Tutup' => $waktu_tutup,
			   'Alamat' => $alamat,
			   'created_at' => $created_at
		   );
			$this->db->insert('t_vendor', $data);
			   
		   }


		   public function editVendor($id_ven,$username,$psw,$nama,$status,$waktu_tutup,$alamat,$created_at)
		   {
	   
			$data = array(
				'Id' => $id_ven,
			   'Username' =>  $username,
			   'Password' =>  $psw ,
			   'Nama'=>  $nama,
			   'Status' => $status,
			   'Waktu_Tutup' => $waktu_tutup,
			   'Alamat' => $alamat,
			   'created_at' => $created_at

		   );
				   $this->db->where('Id', $id_ven);
				   $this->db->update('t_vendor', $data);
		   }



		   public function hapusVendor($id)
		{
	
		   $this->db->where('Id',$id);
		   $this->db->delete('t_vendor');
	
		}


	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

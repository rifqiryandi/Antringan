<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Admin extends CI_Model {
	
		function jmlVendor()
		{
			$this->db->select('count(id) as jml ');
			$this->db->from('t_vendor');
			return $this->db->get()->result();
		}

		function jmlKonsumen()
		{
			$this->db->select('count(id) as jml ');
			$this->db->from('t_konsumen');
			return $this->db->get()->result();
		}
		
		function jmlTransaksi()
		{
			$this->db->select('count(id) as jml ');
			$this->db->from('t_transaksi');
			return $this->db->get()->result();
		}

		function totOmset()
		{
			$this->db->select('sum(Total_Harga) as jml ');
			$this->db->from('t_pesanan');
			return $this->db->get()->result();
		}

		function jmlMenu()
		{
			$this->db->select('count(id) as jml ');
			$this->db->from('t_menu');
			return $this->db->get()->result();
		}
	}
	
	/* End of file M_Admin.php */
	/* Location: ./application/models/M_Admin.php */
?>

<?php

defined('BASEPATH') OR exit('No direct script access allowed');
	
	class M_Menu extends CI_Model {
	

		public function getMenuByVendor($id){
			$this->db->select('*');
			$this->db->from('t_menu');
			$this->db->where('id_vendor',$id);
	
			$query = $this->db->get();
			return $query->result();
		}

		public function getMenu($id){
			$this->db->select('*');
			$this->db->from('t_menu');
			$this->db->where('id',$id);
	
			$query = $this->db->get();
			return $query->result();
		}

		public function editMenu($id,$nama,$harga,$deskripsi,$updated_at){

			$data = array(
			   'nama' =>  $nama,
			   'harga'=>$harga,
			   'deskripsi'=>  $deskripsi,
			   'updated_at' => $updated_at
		   );
		   
		    $this->db->where('id', $id);
			$this->db->update('t_menu', $data);
			   
		   }

		   public function tambahMenu($id_vendor,$nama,$harga,$deskripsi,$created_at){

			$data = array(
				'id_vendor'=>$id_vendor,
			   'nama' =>  $nama,
			   'harga'=>$harga,
			   'deskripsi'=>  $deskripsi,
			   'created_at' => $created_at
		   );
		   
			$this->db->insert('t_menu', $data);
			   
		   }


		   public function changeStatus($id,$status)
		   {
	   
			if ($status == 1) {
				$data = array(
					'status' => 0
			   );
			}elseif($status == 0){
				$data = array(
					'status' => 1
			   );
			}
			
				   $this->db->where('id', $id);
				   $this->db->update('t_menu', $data);
		   }



		//    public function hapusMenu($id)
		// {
	
		//    $this->db->where('Id',$id);
		//    $this->db->delete('t_menu');
	
		// }


	}

<?php $this->load->view('head_foot/header'); ?>
<?php $this->load->view('head_foot/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Vendor</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Vendor</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
              <!-- <h3 class="card-title">DataTable with default features</h3> -->
            </div>
            <!-- /.card-header -->
            <div class="card-body">
            <form method="post" action="<?php echo base_url(); ?>C_Vendor/proseseditvendor">
	              <table id="example1" class="table">
	                <thead>
	                <tr>
	                  <th style="width: 200px">Id</th>
	                  <td> 
	                  	<input type="hidden" name="Id" value="<?php echo $data[0]->id; ?>">
	                  	<input type="text" name="asdas" value="<?php echo $data[0]->id; ?>" class="form-control" disabled></td>
	                </tr>
	                <tr>
	                	<th>Username</th>
	                	<td><input type="text" name="Username" value="<?php echo $data[0]->username; ?>" class="form-control"></td>
	                </tr>
	                <tr>
	                	<th>Password</th>
                    <td><input type="password" name="Password" value="<?php echo $data[0]->password; ?>" class="form-control"></td>
	                </tr>
	                <tr>
	                	<th>Nama</th>
	                	<td><input type="text" name="Nama" value="<?php echo $data[0]->nama; ?>" class="form-control"></td>
	                </tr>
	                <tr>
	                	<th>Api Token</th>
	                	<td><input type="text" name="Kategori" value="<?php echo $data[0]->api_token; ?>" class="form-control" readonly></td>
                  </tr>
                  <tr>
	                	<th>Status</th>
	                	<td><input type="text" name="Status" value="<?php echo $data[0]->status; ?>" class="form-control" ></td>
	                </tr>
                  <tr>
	                	<th>Waktu Tutup</th>
	                	<td><input type="text" name="Waktu_Tutup" value="<?php echo $data[0]->waktu_tutup; ?>" class="form-control" ></td>
	                </tr>
	                <tr>
	                	<th>Alamat</th>
	                	<td><input type="text" name="Alamat" value="<?php echo $data[0]->alamat; ?>" class="form-control" ></td>
	                </tr>
	              </table>
	              <a href="<?php echo base_url(); ?>C_Vendor/viewDataVendor"><input type="button" class="btn btn-primary" name="back" value="Kembali"></a>
	              <input type="submit" name="submit" value="Edit" class="btn btn-primary" style="width: 80px">
	            </form>
              <br>
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.2-pre
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>
<!-- page script -->

</body>
</html>

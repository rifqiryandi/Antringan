<?php $this->load->view('head_foot/header'); ?>
<?php $this->load->view('head_foot/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Konsumen</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Konsumen</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
              <!-- <h3 class="card-title">DataTable with default features</h3> -->
              <!-- <a href="<?php echo base_url(); ?>C_Bank/tambahDataBank"><input type="submit" class="btn btn-primary" name="back" value="Tambah"></a> -->
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped" >
                <thead>
                <tr align="center">
                 
                  <th>Id</th>
                  <th>Nama Pengirim</th>
                  <th>Nomor Rekening</th>
                  <th>Jumlah</th>
                  <th>Bank Pengirim</th>
									<th>Bukti Transfer</th>
									<th>Tipe Permintaan</th>
                  <th>Status</th>
                  <th>Action</th>
                  
                </tr>
                </thead>
                <tbody>

                  <?php foreach ($data as $dt) { ?>
                    <tr>
                      <td> <?php echo $dt->id; ?></td>
                      <td> <?php echo $dt->nama_pengirim; ?></td>
                      <td> <?php echo $dt->no_rekening_pengirim; ?></td>
                      <td><?php echo $dt->jumlah; ?></td>
                      <td><?php echo $dt->bank_pengirim; ?></td>
											<td><?php if(isset($dt->bukti_transfer)){ echo $dt->bukti_transfer; }else{ echo "Kosong";} ?></td>
											<td><?php switch ($dt->tipe_permintaan) {
												case 1:
													echo "Tarik";
													break;
												
												case 2:
													echo "Tambah";
													break;
											}  ?></td>
											<td> <?php echo $dt->status_permintaan; ?></td>
											<center>
											<td style="width: 220px">  
                          <form action="<?php echo base_url(); ?>C_Saldo/viewDetailSaldo" method="post">
                            <input type="hidden" name="id" value="<?php echo $dt->id; ?>"></input>
                            <input type="submit" name="" value="Detail" style="float: left;" class="btn btn-success btn-ok"></input>
                          </form>
                          <!-- Trigger the modal with a button -->
                          <?php if ($dt->tipe_permintaan == 1 &&  $dt->status_permintaan == 2) {?>
                            <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1" class="btn btn-primary" style="float: right">Terima</button>                            
                          <?php }elseif ($dt->tipe_permintaan == 2 && $dt->status_permintaan == 2) {?>
                            <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2" class="btn btn-primary" style="float: right">Terima</button>                            
                          <?php } ?>
                        </td>
											</center>
                    </tr>
                  <?php } ?>

                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.2-pre
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- Modal -->
<div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Terima Permintaan Tarik</h4>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url(); ?>C_Saldo/proEditSaldo" method="post">
          <input type="hidden" name="Id_Konsumen" value="<?php echo $dt->id_konsumen; ?>"></input>
          <input type="hidden" name="Id" value="<?php echo $dt->id; ?>"></input>
          <input type="text" name="kategori" value="<?php switch ($dt->tipe_permintaan) {
												case 1:
													echo "Tarik";
													break;
												
												case 2:
													echo "Tambah";
													break;
											} ?>" hidden></input>
          <input type="number" name="saldo_awal" class="form-control" value="<?php echo $data_k[0]->saldo; ?>" hidden>
          <h3>Nama               :<?php echo $dt->nama_pengirim; ?></h3><br>
          <h3>Jumlah Tarik Saldo :<?php echo $dt->jumlah; ?></h3>
          <input type="number" name="saldo" class="form-control" placeholder="Saldo">
          
        </div>
        <div class="modal-footer">
          <button type="Submit" class="btn btn-success" >Terima</button>
          </form>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

<!-- Modal -->
<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Terima Permintaan Tambah</h4>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url(); ?>C_Saldo/proEditSaldo" method="post">
          <input type="hidden" name="Id_Konsumen" value="<?php echo $dt->id_konsumen; ?>"></input>
          <input type="hidden" name="Id" value="<?php echo $dt->id; ?>"></input>
          <input type="text" name="kategori" value="<?php switch ($dt->tipe_permintaan) {
												case 1:
													echo "Tarik";
													break;
												
												case 2:
													echo "Tambah";
													break;
											} ?>" hidden></input>
          <input type="number" name="saldo_awal" class="form-control" value="<?php echo $data_k[0]->saldo; ?>" hidden>
          <h3>Nama               :<?php echo $dt->nama_pengirim; ?></h3><br>
          <h3>Jumlah Tambah Saldo :<?php echo $dt->jumlah; ?></h3>
          <input type="number" name="saldo" class="form-control" placeholder="Saldo">
          
        </div>
        <div class="modal-footer">
          <button type="Submit" class="btn btn-success" >Terima</button>
          </form>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
</body>
</html>

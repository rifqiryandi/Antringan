<?php $this->load->view('head_foot/header'); ?>
<?php $this->load->view('head_foot/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Konsumen</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Konsumen</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
              <!-- <h3 class="card-title">DataTable with default features</h3> -->
              <a href="<?php echo base_url(); ?>C_Konsumen/tambahDataKonsumen"><input type="submit" class="btn btn-primary" name="back" value="Tambah"></a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Saldo</th>
									<th>Point</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>

                  <?php foreach ($data as $dt) { ?>
                    <tr>
                      <td> <?php echo $dt->id; ?></td>
                      <td> <?php echo $dt->nama; ?></td>
                      <td> <?php echo $dt->email; ?></td>
                      <td> <?php echo $dt->saldo; ?></td>
                      <td> <?php echo $dt->point; ?></td>
                      <td style="width: 220px"> 
                          <form action="<?php echo base_url(); ?>C_Konsumen/viewEditKonsumen" method="post">
                            <input type="hidden" name="id" value="<?php echo $dt->id; ?>" ></input>
                            <input type="submit" name="" value="edit" style="float: left; margin-right: 5px" class="btn btn-warning btn-ok"></input>
                          </form> 
                          <form action="<?php echo base_url(); ?>C_Konsumen/deleteKonsumen" method="post">
                            <input type="hidden" name="id" value="<?php echo $dt->id; ?>"></input>
                            <input type="submit" name="" value="Delete" style="float: left; margin-right: 5px" class="btn btn-danger btn-ok"></input>
                          </form>  
                          <form action="<?php echo base_url(); ?>C_Konsumen/viewDetailKonsumen" method="post">
                            <input type="hidden" name="id" value="<?php echo $dt->id; ?>"></input>
                            <input type="submit" name="" value="Detail" style="float: left;" class="btn btn-success btn-ok"></input>
                          </form>
                        </td>
                    </tr>
                  <?php } ?>

                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.2-pre
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
</body>
</html>

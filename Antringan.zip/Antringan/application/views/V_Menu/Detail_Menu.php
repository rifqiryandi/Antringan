<?php $this->load->view('head_foot/header'); ?>
<?php $this->load->view('head_foot/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Menu</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Menu</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
              <!-- <h3 class="card-title">DataTable with default features</h3> -->
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th style="width: 200px">Id</th>
                  <td><?php echo $data_menu[0]->id; ?></td>
				</tr>
				<tr>
                  <th style="width: 200px">Id</th>
                  <td><?php echo $data_vendor[0]->id; ?></td>
				</tr>
				<tr>
                	<th>Nama Vendor</th>
                	<td><?php echo $data_vendor[0]->nama; ?></td>
                </tr>
                <tr>
                	<th>Nama Menu</th>
                	<td><?php echo $data_menu[0]->nama; ?></td>
                </tr>
                <tr>
                	<th>Harga</th>
                	<td><?php echo $data_menu[0]->harga; ?></td>
                </tr>
                <tr>
                	<th>Deskripsi</th>
                	<td><?php echo $data_menu[0]->deskripsi; ?></td>
                </tr>
                <tr>
                	<th>Status</th>
                	<td><?php echo $data_menu[0]->status; ?></td>
                </tr>
              </table>
              <br>
              <a href="<?php echo base_url(); ?>C_Menu/viewDataMenu?Id=<?php echo $data_vendor[0]->id ?>"><input type="submit" class="btn btn-primary" name="back" value="Kembali"></a>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.2-pre
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>
<!-- page script -->

</body>
</html>

<?php $this->load->view('head_foot/header'); ?>
<?php $this->load->view('head_foot/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Menu Vendor <?= $data_vendor[0]->nama; ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Menu Vendor</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
			  <!-- <h3 class="card-title">DataTable with default features</h3> -->
              <a href="<?php echo base_url(); ?>C_Vendor/viewDataVendor" class="btn btn-info">Kembali</a>
              <a href="<?php echo base_url(); ?>C_Menu/inputMenu?Id_Vendor=<?php echo $data_vendor[0]->id ?>" class="btn btn-primary">(+) Input Data Menu</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
              
                <thead>
                <tr>
				
                  <th>Id</th>
                  <th>Nama Menu</th>
                  <th>Harga</th>
                  <th>Status</th>
				  <th>Action</th>
				
                </tr>
                </thead>
                <tbody>

                  <?php foreach ($data_menu as $dt) { ?>
                    <td> <?php echo $dt->id; ?></td>
                    <td> <?php echo $dt->nama; ?></td>
					<td> <?php echo $dt->harga; ?></td>
                    <td>
					<center>
                      <?php if($dt->status == 1){ ?>
                    <span class="btn btn-sm btn-success">AKTIF</span>
                      <?php }elseif($dt->status == 0) { ?>
                    <span class="btn btn-sm btn-danger">NONAKTIF</span>
                      <?php } ?>
                   </center>
					</td>
                    
                    <td><center>
                    <a href="<?php echo base_url(); ?>C_Menu/detailMenu?Id=<?php echo $dt->id ?>&&Id_Vendor=<?php echo $data_vendor[0]->id ?>" class="btn btn-sm btn-primary">Detail</a>
                    <a href="<?php echo base_url(); ?>C_Menu/updateMenu?Id=<?php echo $dt->id ?>&&Id_Vendor=<?php echo $data_vendor[0]->id ?>" class="btn btn-sm btn-info">Edit</a>
					<?php if($dt->status == 1){ ?>
						<a href="<?php echo base_url(); ?>C_Menu/changeStatus?Id=<?php echo $dt->id ?>&&Status=<?php echo $dt->status ?>&&Id_Vendor=<?php echo $data_vendor[0]->id ?>" class="btn btn-sm btn-danger">NONAKTIFKAN</a>
					  <?php }elseif($dt->status == 0) { ?>
						<a href="<?php echo base_url(); ?>C_Menu/changeStatus?Id=<?php echo $dt->id ?>&&Status=<?php echo $dt->status ?>&&Id_Vendor=<?php echo $data_vendor[0]->id ?>" class="btn btn-sm btn-success">AKTIFKAN</a>
                      <?php } ?>					
				
                  </center></td></tr>
                  <?php } ?>
                  
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.2-pre
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
</body>
</html>

export default abstract class StyledFilterizrElements {
}
